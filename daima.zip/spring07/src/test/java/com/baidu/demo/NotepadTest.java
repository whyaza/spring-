package com.baidu.demo;/*
 *   created by why on 2020/2/25
 */

import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class NotepadTest {

    @Test
    public void test01(){

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        //无论是否主动获取bean对象，spring上下文一加载就会创建bean对象
        Object notepad1 =  context.getBean("notepad");
        Object notepad2 =  context.getBean("notepad");
        //无论咋获取/获取多少次，注入多少次，拿到的都是同一个一开始创建的对象
        System.out.println(notepad1 == notepad2);
    }
}
