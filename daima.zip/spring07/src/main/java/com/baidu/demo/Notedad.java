package com.baidu.demo;/*
 *   created by why on 2020/2/25
 */

public class Notedad {

    public Notedad() {
        super();
        System.out.println("Notepad的构造函数..."+this.toString());
    }



}
