package com.baidu.demo;/*
 *   created by why on 2020/2/25
 */

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
//@Scope(scopeName = "prototype")
//@Scope(scopeName = "single")
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class Notedad2 {

    public Notedad2() {
        super();
        System.out.println("Notepad2的构造函数..."+this.toString());
    }

}
