package soundsystem;/*
 *   created by why on 2020/2/24
 */

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/*
*
* */
@RunWith(SpringJUnit4ClassRunner.class)     //* 自动初始化spring的上下文环境
@ContextConfiguration(classes=AppConfig.class)  //读取配置文件
public class AppTest {

    @Autowired
    private CDPlayer player;

    @Test
    public void testPlay(){
        //可以先写后面的，然后Alt+enter，快速建立局部变量
        /*
        ApplicationContext context = new AnnotationConfigApplicationContext();
        CDPlayer player = context.getBean(CDPlayer.class);
        JUnit之上,Spring又做了进一步的封装,这个集成的测试模块也就是SpringTest。
        junit真挺优雅的哈，不用一堆main在里面测了
         */
        player.play();
    }

}
