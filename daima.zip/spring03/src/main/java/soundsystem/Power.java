package soundsystem;/*
 *   created by why on 2020/2/24
 */

import org.springframework.stereotype.Component;

@Component
public class Power {

    public Power() {
        super();
    }

    /*
    * gongdian
    * */
    public void supply(){
        System.out.println("电源供电中...");
    }
}
