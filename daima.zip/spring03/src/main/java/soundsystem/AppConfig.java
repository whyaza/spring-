package soundsystem;/*
 *   created by why on 2020/2/24
*   Spring 程序配置类
*
 */

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class AppConfig {
    /**
     * 
     *
     * */
}
