package soundsystem;
/*
 *   created by why on 2020/2/24
 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CDPlayer {

    @Autowired(required = false)
    private CompactDisc cd;
    @Autowired
    private Power power;

    public CDPlayer() {
        super();
        System.out.println("CDPlayer无参构造函数");
    }

    //ctrl+shift+/   快速注解
    /*@Autowired
    public void setCd(CompactDisc cd) {
        this.cd = cd;
        System.out.println("setCd");
    }
    @Autowired
    public void setPower(Power power) {
        this.power = power;
        System.out.println("setPower");
    }*/

    /*
    @Autowired
    public CDPlayer(CompactDisc cd) {
        this.cd = cd;
        System.out.println("CDPlayer有参构造函数");
    }*/

    //@Autowired
    public CDPlayer(CompactDisc cd, Power power) {
        this.cd = cd;
        this.power = power;
        System.out.println("CDPlayer多参构造函数");
    }

    /*@Autowired
    public void prepare(CompactDisc cd,Power power){
        this.cd = cd;
        this.power = power;
        System.out.println("prepare diaoyong");
    }*/

    public void play(){
        power.supply();
        if(cd != null)
            cd.play();
    }
}
