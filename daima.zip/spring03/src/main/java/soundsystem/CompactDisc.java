package soundsystem;
/*
 *   created by why on 2020/2/24
 */

import org.springframework.stereotype.Component;

//@Component
public class CompactDisc {
    /*ctrl + o   一堆父类的可重写的方法*/
    public CompactDisc() {
        super();
        System.out.println("CompactDisc无参构造函数");
    }

    public void play(){
        System.out.println("正在播放音乐。。。");
    }
}
