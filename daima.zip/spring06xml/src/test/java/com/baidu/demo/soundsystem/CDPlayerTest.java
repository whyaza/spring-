package com.baidu.demo.soundsystem;/*
 *   created by why on 2020/2/25
 */

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext-contructor.xml")
public class CDPlayerTest {

    @Autowired
    private CDPlayer cdPlayer1;

    @Autowired
    private CDPlayer cdPlayer2;

    @Autowired
    private CDPlayer cdPlayer3;

    @Test
    public void test(){
        //cdPlayer1.play();
        cdPlayer2.play();
    }

    @Test
    public void test03(){
        //cdPlayer1.play();
        cdPlayer3.play();
    }
}
