package com.baidu.demo.soundsystem;/*
 *   created by why on 2020/2/25
 */

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext-contructor.xml")
public class AppTest {

    @Autowired
    private CompactDisc compactDisc1;

    @Autowired
    private CompactDisc compactDisc2;   //这个名字和xml中bean的id名字需一致

    //@Autowired
    //@Qualifier("compactDisc12")
    //private CompactDisc compactDisc3;   //２，３是同一个对象

    @Test
    public void test01(){
        compactDisc1.play();
        //compactDisc2.play();
        //compactDisc3.play();
    }

    @Test
    public void test02(){
        compactDisc1.play();
        //compactDisc2.play();
        //compactDisc3.play();
    }
}
