package com.baidu.demo.soundsystem;/*
 *   created by why on 2020/2/25
 */

public class Music {

    private String title;
    private String duration;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
        System.out.println("--->:在"+this.toString()+ "中注入title");
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
        System.out.println("--->:在"+this.toString()+ "中注入duration");
    }

    public Music() {
        super();
        System.out.println("Music构造函数..."+this.toString());
    }

    public Music(String title, String duration) {
        this.title = title;
        this.duration = duration;
    }
}
