package com.baidu.demo.soundsystem;/*
 *   created by why on 2020/2/25
 */

public class CDPlayer {

    private CompactDisc cd;

    public CDPlayer() {
        super();
        System.out.println("CDPlayer无参构造函数"+this.toString());
    }

    public CDPlayer(CompactDisc cd) {
        this.cd = cd;
        System.out.println("CDPlayer有参构造函数"+this.toString());
    }

    public void setCd(CompactDisc cd) {
        this.cd = cd;
        System.out.println("--->:在"+this.toString()+ "中注入cd对象");
    }

    public void play(){
        System.out.println("CDPlayer:" + this.toString());
        cd.play();
    }
}
