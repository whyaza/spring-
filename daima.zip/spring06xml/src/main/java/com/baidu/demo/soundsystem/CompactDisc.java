package com.baidu.demo.soundsystem;/*
 *   created by why on 2020/2/25
 */

import java.util.List;
import java.util.Set;

public class CompactDisc {

    private String title;
    private String artist;
    //private List<String> tracks;
    private Set<Music> tracks;

    public CompactDisc() {
        super();
        System.out.println("CompactDisc0参构造函数.."+this.toString());
    }

    public CompactDisc(String title, String artist) {
        this.title = title;
        this.artist = artist;
        System.out.println("CompactDisc2参构造函数.."+this.toString());
    }

    public CompactDisc(String title, String artist, Set<Music> tracks) {
        this.title = title;
        this.artist = artist;
        this.tracks = tracks;
        System.out.println("CompactDisc3参构造函数.."+this.toString());
    }

    public void setTitle(String title) {
        this.title = title;
        System.out.println("--->:在"+this.toString()+ "中注入title");
    }

    public void setArtist(String artist) {
        this.artist = artist;
        System.out.println("--->:在"+this.toString()+ "中注入artist");
    }

    public void setTracks(Set<Music> tracks) {
        this.tracks = tracks;
        System.out.println("--->:在"+this.toString()+ "中注入tracks");
    }

    public void play(){
        System.out.println("播放CD音乐"+this.toString()+" "+ this.title + " by " + this.artist);
        for(Music track: this.tracks){
            System.out.println("music: " + track.getTitle() + "duration: "+ track.getDuration());
        }
    }
}
