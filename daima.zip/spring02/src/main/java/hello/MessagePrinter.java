package hello;
/*
 *   created by why on 2020/2/24
 *   打印机
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


public class MessagePrinter {

    public MessagePrinter() {
        super();
        System.out.println("MessagePrinter...");
    }

    private MessageService service;

    /*
    * 设置 service的值
    *   Autowired自动设置
    * */
    @Autowired
    public void setService(MessageService service) {
        this.service = service;
    }

    public void printMessage(){
        System.out.println(this.service.getMessage());
    }
}
