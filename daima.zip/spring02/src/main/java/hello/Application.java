package hello;
/*
 *   created by why on 2020/2/24
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Application {
    public static void main(String[] args){
        ApplicationContext context = new ClassPathXmlApplicationContext("ApplicationContext.xml");
        //需要确保的是，resources是资源根目录。

        MessagePrinter printer = context.getBean(MessagePrinter.class);
        printer.printMessage();
    }
}
