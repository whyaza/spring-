package com.baidu.demo.config;/*
 *   created by why on 2020/2/25
 */

import com.baidu.demo.dao.UserDao;
import com.baidu.demo.dao.impl.UserDaoCache;
import com.baidu.demo.dao.impl.UserDaoNormal;
import com.baidu.demo.service.UserService;
import com.baidu.demo.service.impl.UserServiceNormal;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class AppConfig {

    //@Bean("normal")        //spring读@Configuration，的bean
    //@Primary      首选bean
    //@Qualifier("normal")        //使用Qualifier注解
    //@Bean("normal")
    @Bean
    public UserDao userDaoNormal(){
        System.out.println("创建UserDaoNormal对象");
        return new UserDaoNormal();
    }

    //@Bean("cache")       //spring读@Configuration，的bean
    //@Qualifier("cache")
    //@Bean("cache")
    @Bean
    public UserDao userDaoCache(){
        System.out.println("创建UserDaoCache对象");
        return new UserDaoCache();
    }

    @Bean
    public UserService userServiceNormal(@Qualifier("userDaoNormal")  UserDao userDao){
        //另二种写法；在参数中写
        /*System.out.println("创建UserService对象");
        UserDao userDao = userDaoNormal();  //spring会拦截全部的userDaoNormal()，最终只会执行一次，是单例的*/

        //利用setter方法注入:这就说明他可以注入任何的方法
        System.out.println("创建UserService对象");
        UserServiceNormal userService = new UserServiceNormal();
        userService.setUserDao(userDao);
        return userService;
    }

}
