package com.baidu.demo.service.impl;/*
 *   created by why on 2020/2/25
 */

import com.baidu.demo.dao.UserDao;
import com.baidu.demo.service.UserService;

public class UserServiceNormal implements UserService {

    private UserDao userDao;

    public UserServiceNormal() {
    }

    public UserServiceNormal(UserDao userDao) {
        this.userDao = userDao;
    }

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    public void add(){
        userDao.add();
    }
}
