package com.baidu.demo.dao.impl;/*
 *   created by why on 2020/2/25
 */

import com.baidu.demo.dao.UserDao;

public class UserDaoNormal implements UserDao {

    public void add(){
        System.out.println("添加用户到数据库中..");
    }
}
