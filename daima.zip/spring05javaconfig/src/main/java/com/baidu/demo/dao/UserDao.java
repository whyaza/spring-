package com.baidu.demo.dao;/*
 *   created by why on 2020/2/25
 */

public interface UserDao {
    void add();
}
