package com.baidu.demo.service;/*
 *   created by why on 2020/2/25
 */

public interface UserService {
    void add();
}
