package com.baidu.demo;/*
 *   created by why on 2020/2/26
 */

public class PersonFactory {

    public static Person createPerson1(){
        System.out.println("静态方法创建Person....");
        return new Person();
    }

    public Person createPerson2(){
        System.out.println("实例方法创建Person....");
        return new Person();
    }
}
