package hello;
/*
 *   created by why on 2020/2/24
 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan
public class Application {
    public static void main(String[] args){
        /*
        System.out.println("application");

        MessagePrinter printer = new MessagePrinter();
        MessageService service = new MessageService();

        printer.setService(service);
        printer.printMessage();
         */
        //基于注解的方式初始化spring容器
        //初始化ｓｐｒｉｎｇ　容器
        //!通过 * @ComponentScan 扫描@Component注解的类，创建对象的时候就可以不用重新new
        ApplicationContext context = new AnnotationConfigApplicationContext(Application.class);

        //!从容器中 获取对象
        /*MessagePrinter  printer = context.getBean(MessagePrinter.class);
        MessageService  service = context.getBean(MessageService.class);

        System.out.println(printer);
        System.out.println(service);

        printer.setService(service);
        printer.printMessage();
        */
        //帮助 创建对象之间的关联关系:
        //由于在MessagePrinter中的setService上家了@Autowired
        //在获取对象初始化的时候，就被自动调用了
        MessagePrinter  printer = context.getBean(MessagePrinter.class);
        printer.printMessage();
        //这个就是控制反转IOC：就是把创建对象，对象之间关系的维护的控制权
        //从由程序员管理，到由spring容器进行管理.

        //DI:
        //对象和对象依赖关系的创建过程，这个动作，就叫依赖注入。

        //AOP：等待
    }
}
