package com.baidu.demo.service.impl;/*
 *   created by why on 2020/2/24
 */

import com.baidu.demo.dao.UserDao;
import com.baidu.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

//@Component
@Service
//Service层利用@Service代替@Component
//@Primary        //使用首选bean解决自动装配的歧义性
public class UserServiceNormal implements UserService {

    @Autowired
    private UserDao userDao;

    public void add(){
        userDao.add();
    }
}
