package com.baidu.demo.web;/*
 *   created by why on 2020/2/24
 */

import com.baidu.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

//springMVC就是对web/即controller层做的一个企业级的架构
//@Component
@Controller     //Controller层利用@Controller代替@Component : 语义明确
public class UserController {

    @Autowired
    @Qualifier("userServiceNormal")
    private UserService userService;

    public void add(){
        userService.add();
    }
}
