package com.baidu.demo.dao;/*
 *   created by why on 2020/2/24
 */

public interface UserDao {
    void add();
}
