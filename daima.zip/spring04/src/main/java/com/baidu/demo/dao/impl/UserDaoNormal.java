package com.baidu.demo.dao.impl;/*
 *   created by why on 2020/2/24
 */

import com.baidu.demo.dao.UserDao;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

//@Component
@Repository //Dao层利用@Repository代替@Component : 语义明确
public class UserDaoNormal implements UserDao {
    public void add(){
        System.out.println("添加用户到数据库中...");
    }
}
