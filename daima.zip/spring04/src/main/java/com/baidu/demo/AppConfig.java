package com.baidu.demo;/*
 *   created by why on 2020/2/24
 */

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@ComponentScan      //默认：spring会扫描这个类所在的包，以及在这个类下的所有有@Component注解的类
//可以设置@ComponentScan("包名")
//@ComponentScan(basePackages = {"","",""...})
//@ComponentScan(basePackageClasses = {UserServiceNormal.class,...})
public class AppConfig {

}
