package com.baidu.demo.service.impl;/*
 *   created by why on 2020/2/24
 */

import com.baidu.demo.service.UserService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
//@Qualifier("festival")    //使用限定符解决自动装配的歧义性 : 语义明确
public class UserServiceFestival implements UserService {

    public void add(){
        System.out.println("注册用户并发送优惠券");
    }
}
