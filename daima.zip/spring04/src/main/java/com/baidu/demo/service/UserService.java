package com.baidu.demo.service;/*
 *   created by why on 2020/2/24
 */

public interface UserService {

    void add();

}
