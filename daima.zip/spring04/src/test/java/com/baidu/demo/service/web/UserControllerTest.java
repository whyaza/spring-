package com.baidu.demo.service.web;/*
 *   created by why on 2020/2/24
 */


import com.baidu.demo.AppConfig;
import com.baidu.demo.service.UserService;
import com.baidu.demo.web.UserController;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= AppConfig.class)
public class UserControllerTest {

    @Autowired
    private UserController usercontroller;
    //多个实现类会产生歧义性

    @Test
    public void testAdd(){
        usercontroller.add();
    }
}
