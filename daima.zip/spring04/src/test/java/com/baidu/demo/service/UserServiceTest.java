package com.baidu.demo.service;/*
 *   created by why on 2020/2/24
 */


import com.baidu.demo.AppConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes= AppConfig.class)
@ContextConfiguration("classpath:applicationContext.xml")   //通过xml启用组件扫描
public class UserServiceTest {

    //@Autowired
    //@Qualifier("festival")  //使用限定符解决自动装配的歧义性
    //@Qualifier("normal")     //使用限定符+类id解决自动装配的歧义性
    //@Qualifier("userServiceNormal")


    //Autowired Qualifier   是spring的标准
    //Resource是java的解决标准
    @Resource(name = "userServiceNormal")
    private UserService userService;
    //多个实现类会产生歧义性

    @Test
    public void testAdd(){
        userService.add();
    }
}
